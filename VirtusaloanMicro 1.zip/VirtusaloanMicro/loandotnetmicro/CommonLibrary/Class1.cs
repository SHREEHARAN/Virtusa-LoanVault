﻿namespace CommonLibrary;
public class Class1
{

}
