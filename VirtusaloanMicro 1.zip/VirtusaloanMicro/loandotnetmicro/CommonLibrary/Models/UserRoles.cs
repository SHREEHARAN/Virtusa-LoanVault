﻿namespace CommonLibrary.Models
{
    public static class UserRoles
    {
        public const string User = "Customer";

        public const string User1 = "LoanManager";
        public const string User2 = "BranchManager";
    }
}
