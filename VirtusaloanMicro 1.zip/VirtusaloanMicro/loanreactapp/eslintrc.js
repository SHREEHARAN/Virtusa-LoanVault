module.exports = {
    parser: 'babel-eslint',
    // Other ESLint configurations
  };
  