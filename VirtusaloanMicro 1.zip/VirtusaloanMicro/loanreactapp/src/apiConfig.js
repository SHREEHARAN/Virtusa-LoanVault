
const API_BASE_URL = 'https://8080-abfdabeabcbaed313801225dbafbddbadadbdone.premiumproject.examly.io';

export default API_BASE_URL;
